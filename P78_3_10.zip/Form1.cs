﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P78_3_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        string op;
        int a;
        int b;
        int result;
        private void Form1_Load(object sender, EventArgs e)
        {
            //Random rnd = new Random();
            //int a = rnd.Next(9) + 1;
            //int b = rnd.Next(9) + 1;
            //int c = rnd.Next(4);
            //switch (c)
            //{
            //    case 0: op = "+"; result = a + b; break;
            //    case 1: op = "-"; result = a - b; break;
            //    case 2: op = "*"; result = a * b; break;
            //    case 3: op = "/"; result = a / b; break;
            //}
            //label1.Text = a.ToString();
            //label3.Text = b.ToString();
            //label2.Text = op;       


        }
        int answer;
        private void button1_Click(object sender, EventArgs e)
        {
            int answer = int.Parse(textBox1.Text);
            if (answer == result)
            {
                label5.Text = "回答正确！";
                this.BackColor = Color.FromArgb(0, 255, 0);
            }
            else
            {
                label5.Text = "回答错误!";
                this.BackColor = Color.FromArgb(255, 100, 100);
            }
        }

        private void Form1_ForeColorChanged(object sender, EventArgs e)
        {
       
        }

        private void Form1_BackColorChanged(object sender, EventArgs e)
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int n ;
            for(n=1; n<= 10; n++)
            {
                Random rnd = new Random();
                int a = rnd.Next(9) + 1;
                int b = rnd.Next(9) + 1;
                int c = rnd.Next(4);
                switch (c)
                {
                    case 0: op = "+"; result = a + b; break;
                    case 1: op = "-"; result = a - b; break;
                    case 2: op = "*"; result = a * b; break;
                    case 3: op = "/"; result = a / b; break;
                }
                label1.Text = a.ToString();
                label3.Text = b.ToString();
                label2.Text = op;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //if (timer2.Enabled == false)
            //{
            //    timer2.Enabled = true;
            //    int answer = int.Parse(textBox1.Text);
            //    if (answer == result)
            //    {
            //        label5.Text = "回答正确！";
            //        this.BackColor = Color.FromArgb(0, 255, 0);
            //    }
            //    else
            //    {
            //        label5.Text = "回答错误!";
            //        this.BackColor = Color.FromArgb(255, 100, 100);
            //    }
            //}
            //else
            //{
                //timer2.Enabled = false;
                this.BackColor = Color.FromArgb(255, 255, 255);
            label5.Text = "回复";

            //}
        }

        private void label6_Click(object sender, EventArgs e)
        {
        
        }

    
    }
}
